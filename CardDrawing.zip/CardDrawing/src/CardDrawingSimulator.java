import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import objects.Card;
import objects.Deck;

public class CardDrawingSimulator extends JFrame {
	public static final String FILENAME = "CardDrawLog.txt";
	public static final String FILENAME_CSV = "CardDrawLogCSV.csv";
	
	// GUI Components
	Font font = new Font("Helvetica", Font.PLAIN, 12);
	Font lrgFont = new Font("Helvetica", Font.PLAIN, 14);
	JPanel controls, editor, analyze, cardsPane, idealGraphs, actualGraph;
	JLabel trialsLbl, drawCardLbl, replacementLbl, idealProbLbl, actualProbLbl;
	JLabel dTotalLbl, probLbl, dcardsLbl;
	JButton wRepBtn, woRepBtn, computeBtn;
	JComboBox<String> numberCards, dnumberCards;
	JTextField trialsFld, dTotalFld, dIdealFld, dActualFld;
	JButton drawBtn;
	JScrollPane scroll;
	JTextArea console;
	JPanel backCardPane, frontCardPane;
	JLabel frontImage, backImage, otherStats;
	JLabel idealLbl, actualLbl, diffLbl;
	JLabel meanLbl, medianLbl, modeLbl, varLbl, sdLbl;
	JTextField idealMeanFld, idealMedianFld, idealModeFld, idealVarFld, idealSDFld;
	JTextField actualMeanFld, actualMedianFld, actualModeFld, actualVarFld, actualSDFld;	
	JTextField diffMeanFld, diffMedianFld, diffModeFld, diffVarFld, diffSDFld;	
	
	// Program Components	
	Logger log;
	int numCards, numTrials, from, to;
	Scanner sc;
	Deck deck;
	Boolean validDraw, validTrial;
	
	public CardDrawingSimulator(Logger log){
		this.log = log;
		init();
	}
	
	public void init(){
		validDraw = true;
		validTrial = true;
		numCards = 0;
		numTrials = 0;
		deck = new Deck();
		initGUI();
	}
	
	public void start(){
//		sc = new Scanner(System.in);
//		while(validDraw) {
//			System.out.print("Please input number of cards (1 to 5): ");
//			numCards = sc.nextInt();
//			if(validateDraw(numCards))
//				validDraw = true;
//			else validDraw = false;
//		}
//		
//		while(validTrial) {
//			System.out.print("Please enter number of trials (10 to 100000): ");
//			numTrials = sc.nextInt();
//			if(validateTrials(numTrials))
//				validTrial = true;
//			else validTrial = false;
//		}
		
		ArrayList<Card> result = deck.draw(1, false);
		frontImage.setIcon(result.get(0).getIcon());
		cardsPane.repaint();
		
		console.append("There are 10 trials.\n");
		console.append("There are 3 cards need to be drawn for each trial.\n");
		console.append("Trial # 1\n");
		console.append("Card # 1: 10 of Hearts\n");
		console.append("Card # 2: 4 of Spades\n");
		console.append("Card # 3: Jack of Diamonds\n");
		console.append("Trial # 2\n");
		console.append("Card # 1: Queen of Clubs\n");
		console.append("Card # 2: 3 of Spades\n");
		console.append("Card # 3: 7 of Hearts\n");
		console.append("Trial # 3\n");
		console.append("Card # 1: 10 of Hearts\n");
		console.append("Card # 2: 4 of Spades\n");
		console.append("Card # 3: Jack of Diamonds\n");
		console.append("Trial # 4\n");
		console.append("Card # 1: Ace of Diamonds\n");
		console.append("Card # 2: 5 of Spades\n");
		console.append("Card # 3: King of Clubs\n");
		console.append("Trial # 5\n");
		console.append("Card # 1: 3 of Hearts\n");
		console.append("Card # 2: 4 of Spades\n");
		console.append("Card # 3: 9 of Diamonds\n");
		console.append("Trial # 6\n");
		console.append("Card # 1: 6 of Clubs\n");
		console.append("Card # 2: Ace of Spades\n");
		console.append("Card # 3: 10 of Diamonds\n");
		console.append("Trial # 7\n");
		console.append("Card # 1: 2 of Spades\n");
		console.append("Card # 2: Jack of Clubs\n");
		console.append("Card # 3: 8 of Hearts\n");
		console.append("Trial # 8\n");
		console.append("Card # 1: King of Clubs\n");
		console.append("Card # 2: 3 of Spades\n");
		console.append("Card # 3: 4 of Diamonds\n");
		console.append("Trial # 9\n");
		console.append("Card # 1: 6 of Hearts\n");
		console.append("Card # 2: Ace of Hearts\n");
		console.append("Card # 3: 9 of Spades\n");
		console.append("Trial # 10\n");
		console.append("Card # 1: King of Hearts\n");
		console.append("Card # 2: Ace of Clubs\n");
		console.append("Card # 3: 5 of Hearts\n");
	}
	
	public boolean validateDraw(int x) {
		if(x > 5 || x < 1) {
			System.out.println("Invalid Input. Try Again");
			return true;
		}
		return false;
	}
	
	public boolean validateTrials(int x) {
		if(x > 100000 || x < 1) {
			System.out.println("Invalid Input. Try Again");
			return true;
		}
		return false;
	}
	
	public void drawWith(int numCards, int numTrials) {
		ArrayList<Card> resultCards;
		int sum = 0 ;
		System.out.println("\nWith Replacement Results");
		log.writeFile(FILENAME, numTrials + " TRIALS WITH REPLACEMENT");
		for(int i = 0; i < numTrials; i++) {
			log.writeFile(FILENAME, "====================TRIAL " + (i+1) + "====================");
			System.out.println("Trial # " + (i+1));
			resultCards = deck.draw(numCards, true);
			sum = getSumCard(resultCards);
			displayTrial(resultCards);
			System.out.println("Sum: " + sum);
			log.writeCSV(FILENAME_CSV, numTrials, i+1, numCards, sum, true);
		}
	}
	
	public void drawWithout(int numCards, int numTrials) {
		ArrayList<Card> resultCards;
		int sum = 0 ;
		System.out.println("\nWithout Replacement Results");
		log.writeFile(FILENAME, numTrials + " TRIALS WITHOUT REPLACEMENT");
		for(int i = 0; i < numTrials; i++) {
			log.writeFile(FILENAME, "====================TRIAL " + (i+1) + "====================");
			System.out.println("Trial # " + (i+1));
			resultCards = deck.draw(numCards, false);
			sum = getSumCard(resultCards);
			displayTrial(resultCards);
			System.out.println("Sum: " + sum);
			log.writeCSV(FILENAME_CSV, numTrials, i+1, numCards, sum, false);
		}
	}
	
	public void displayTrial(ArrayList<Card> result) {
		for(int i = 0; i < result.size(); i++) {
			System.out.println("Card "+(i+1)+": " + result.get(i).getRank() + " " + result.get(i).getSuit());
			log.writeFile(FILENAME, "Card "+(i+1)+": " + result.get(i).getRank() + " " + result.get(i).getSuit());
		}
	}
	
	public int getSumCard(ArrayList<Card> result) {
		int sum = 0;
		for(int i = 0; i < result.size(); i++) {
			sum += result.get(i).getRank();
		}
		return sum;
	}
	
	public void initGUI() {
		this.setTitle("Card Drawing Simulator");
		this.setLayout(null);
		this.setSize (1240,720);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		controls = new JPanel();
		controls.setBounds(10,10, 350, 360);
		controls.setLayout(null);
		controls.setBackground(Color.white);
		controls.setVisible(true);		
		add(controls);
		initControls();
		
		editor = new JPanel();
		editor.setBounds(10,380, 350, 300);
		editor.setLayout(null);
		editor.setBackground(Color.white);
		editor.setVisible(true);		
		add(editor);
		initEditor();
		
		analyze = new JPanel();
		analyze.setBounds(370,10, 400, 350);
		analyze.setLayout(null);
		analyze.setBackground(Color.white);
		analyze.setVisible(true);		
		add(analyze);
		initAnalyze();
		
		cardsPane = new JPanel();
		cardsPane.setBounds(370,370, 400, 310);
		cardsPane.setLayout(null);
		cardsPane.setBackground(Color.white);
		cardsPane.setVisible(true);		
		add(cardsPane);
		initCards();
		
		idealGraphs = new JPanel();
		idealGraphs.setBounds(780,10, 440, 350);
		idealGraphs.setLayout(null);
		idealGraphs.setBackground(Color.white);
		idealGraphs.setVisible(true);		
		add(idealGraphs);
		initIdealGraphs();
		
		actualGraph = new JPanel();
		actualGraph.setBounds(780,370, 440, 310);
		actualGraph.setLayout(null);
		actualGraph.setBackground(Color.white);
		actualGraph.setVisible(true);		
		add(actualGraph);
		initActualGraphs();
		
		this.repaint();
	}
	
	public void initControls() {
		drawCardLbl = new JLabel("Number of Cards to Draw");
		drawCardLbl.setFont(font);
		drawCardLbl.setVisible(true);
		drawCardLbl.setBounds(10, 10, 150, 20);
		controls.add(drawCardLbl);
		
		String[] choicesCards = {"1", "2", "3", "4", "5"};
		numberCards = new JComboBox<String>(choicesCards);
		numberCards.setSelectedItem(0);
		numberCards.setVisible(true);
		numberCards.setBounds(10, 30, 150, 30);
		controls.add(numberCards);
		
		trialsLbl = new JLabel("Number of Trials");
		trialsLbl.setFont(font);
		trialsLbl.setVisible(true);
		trialsLbl.setBounds(180, 10, 150, 20);
		controls.add(trialsLbl);
		
		trialsFld = new JTextField();
		trialsFld.setVisible(true);
		trialsFld.setBounds(180, 30, 150, 30);
		controls.add(trialsFld);
		
		drawBtn = new JButton("Draw Cards");
		drawBtn.setBounds(10, 70, 320, 35);
		drawBtn.setVisible(true);
		drawBtn.setBackground(Color.white);
		controls.add(drawBtn);
		
		probLbl = new JLabel("Compute for Probability", JLabel.CENTER);
		probLbl.setFont(lrgFont);
		probLbl.setVisible(true);
		probLbl.setBounds(10,120, 320, 30);
		probLbl.setBackground(Color.LIGHT_GRAY);
		probLbl.setOpaque(true);
		controls.add(probLbl);
		
		dcardsLbl = new JLabel("Number of Cards to Draw");
		dcardsLbl.setFont(font);
		dcardsLbl.setVisible(true);
		dcardsLbl.setBounds(10, 160, 150, 20);
		controls.add(dcardsLbl);
		
		dnumberCards = new JComboBox<String>(choicesCards);
		dnumberCards.setSelectedItem(0);
		dnumberCards.setVisible(true);
		dnumberCards.setBounds(10, 180, 150, 30);
		controls.add(dnumberCards);
		
		dTotalLbl = new JLabel("Desired Total");
		dTotalLbl.setFont(font);
		dTotalLbl.setVisible(true);
		dTotalLbl.setBounds(180, 160, 150, 20);
		controls.add(dTotalLbl);
		
		dTotalFld = new JTextField();
		dTotalFld.setVisible(true);
		dTotalFld.setBounds(180, 180, 150, 30);
		controls.add(dTotalFld);
		
		computeBtn = new JButton("Compute Probability");
		computeBtn.setBounds(10, 220, 320, 35);
		computeBtn.setVisible(true);
		computeBtn.setBackground(Color.white);
		controls.add(computeBtn);
		
		wRepBtn = new JButton("With Replacement");
		wRepBtn.setBounds(10, 265, 160, 30);
		wRepBtn.setVisible(true);
		wRepBtn.setBackground(Color.white);
		controls.add(wRepBtn);
		
		woRepBtn = new JButton("Without Replacement");
		woRepBtn.setBounds(170, 265, 160, 30);
		woRepBtn.setVisible(true);
		woRepBtn.setBackground(Color.white);
		controls.add(woRepBtn);
		
		idealProbLbl = new JLabel("Ideal Probability");
		idealProbLbl.setFont(font);
		idealProbLbl.setVisible(true);
		idealProbLbl.setBounds(10, 300, 150, 20);
		controls.add(idealProbLbl);
		
		actualProbLbl = new JLabel("Actual Probability");
		actualProbLbl.setFont(font);
		actualProbLbl.setVisible(true);
		actualProbLbl.setBounds(180, 300, 150, 20);
		controls.add(actualProbLbl);
		
		dIdealFld = new JTextField();
		dIdealFld.setVisible(true);
		dIdealFld.setBounds(10, 320, 150, 30);
		dIdealFld.setEnabled(false);
		controls.add(dIdealFld);
		
		dActualFld = new JTextField();
		dActualFld.setVisible(true);
		dActualFld.setBounds(180, 320, 150, 30);
		dActualFld.setEnabled(false);
		controls.add(dActualFld);
	}
	
	public void initEditor() {	    
	    console = new JTextArea();
	    console.setEditable(false);
	    console.setBounds(10, 10, 330, 280);
	    console.setVisible(true);
	    console.setLineWrap(true);
	    console.setWrapStyleWord(true);
	     
	    scroll = new JScrollPane(console);
	    scroll.setBounds(10, 10, 330, 280);
	    scroll.setBorder(BorderFactory.createLineBorder(Color.black));
	    editor.add(scroll);
	}
	
	public void initAnalyze() {
		otherStats = new JLabel("Other Statistics", JLabel.CENTER);
		otherStats.setFont(lrgFont);
		otherStats.setVisible(true);
		otherStats.setBounds(10, 10, 380, 30);
		otherStats.setBackground(Color.LIGHT_GRAY);
		otherStats.setOpaque(true);
		analyze.add(otherStats);
		
		meanLbl = new JLabel("Mean", JLabel.CENTER);
		meanLbl.setFont(font);
		meanLbl.setVisible(true);
		meanLbl.setBounds(10, 95, 100, 20);
		analyze.add(meanLbl);
		
		medianLbl = new JLabel("Median", JLabel.CENTER);
		medianLbl.setFont(font);
		medianLbl.setVisible(true);
		medianLbl.setBounds(10, 140, 100, 20);
		analyze.add(medianLbl);
		
		modeLbl = new JLabel("Mode", JLabel.CENTER);
		modeLbl.setFont(font);
		modeLbl.setVisible(true);
		modeLbl.setBounds(10, 185, 100, 20);
		analyze.add(modeLbl);
		
		varLbl = new JLabel("Variance", JLabel.CENTER);
		varLbl.setFont(font);
		varLbl.setVisible(true);
		varLbl.setBounds(10, 230, 100, 20);
		analyze.add(varLbl);
		
		sdLbl = new JLabel("Standard Dev", JLabel.CENTER);
		sdLbl.setFont(font);
		sdLbl.setVisible(true);
		sdLbl.setBounds(10, 275, 100, 20);
		analyze.add(sdLbl);
		
		idealLbl = new JLabel("Ideal", JLabel.CENTER);
		idealLbl.setFont(font);
		idealLbl.setVisible(true);
		idealLbl.setBounds(120, 55, 75, 20);
		analyze.add(idealLbl);
		
		idealMeanFld = new JTextField("0.0000");
		idealMeanFld.setFont(font);
		idealMeanFld.setVisible(true);
		idealMeanFld.setBounds(120, 90, 75, 35);
		idealMeanFld.setEnabled(false);
		analyze.add(idealMeanFld);
		
		idealMedianFld = new JTextField("0.0000");
		idealMedianFld.setFont(font);
		idealMedianFld.setVisible(true);
		idealMedianFld.setBounds(120, 135, 75, 35);
		idealMedianFld.setEnabled(false);
		analyze.add(idealMedianFld);
		
		idealModeFld = new JTextField("0.0000");
		idealModeFld.setFont(font);
		idealModeFld.setVisible(true);
		idealModeFld.setBounds(120, 180, 75, 35);
		idealModeFld.setEnabled(false);
		analyze.add(idealModeFld);
		
		idealVarFld = new JTextField("0.0000");
		idealVarFld.setFont(font);
		idealVarFld.setVisible(true);
		idealVarFld.setBounds(120, 225, 75, 35);
		idealVarFld.setEnabled(false);
		analyze.add(idealVarFld);
		
		idealSDFld = new JTextField("0.0000");
		idealSDFld.setFont(font);
		idealSDFld.setVisible(true);
		idealSDFld.setBounds(120, 270, 75, 35);
		idealSDFld.setEnabled(false);
		analyze.add(idealSDFld);
		
		actualLbl = new JLabel("Actual", JLabel.CENTER);
		actualLbl.setFont(font);
		actualLbl.setVisible(true);
		actualLbl.setBounds(200, 55, 75, 20);
		analyze.add(actualLbl);
		
		actualMeanFld = new JTextField("0.0000");
		actualMeanFld.setFont(font);
		actualMeanFld.setVisible(true);
		actualMeanFld.setBounds(200, 90, 75, 35);
		actualMeanFld.setEnabled(false);
		analyze.add(actualMeanFld);
		
		actualMedianFld = new JTextField("0.0000");
		actualMedianFld.setFont(font);
		actualMedianFld.setVisible(true);
		actualMedianFld.setBounds(200, 135, 75, 35);
		actualMedianFld.setEnabled(false);
		analyze.add(actualMedianFld);
		
		actualModeFld = new JTextField("0.0000");
		actualModeFld.setFont(font);
		actualModeFld.setVisible(true);
		actualModeFld.setBounds(200, 180, 75, 35);
		actualModeFld.setEnabled(false);
		analyze.add(actualModeFld);
		
		actualVarFld = new JTextField("0.0000");
		actualVarFld.setFont(font);
		actualVarFld.setVisible(true);
		actualVarFld.setBounds(200, 225, 75, 35);
		actualVarFld.setEnabled(false);
		analyze.add(actualVarFld);
		
		actualSDFld = new JTextField("0.0000");
		actualSDFld.setFont(font);
		actualSDFld.setVisible(true);
		actualSDFld.setBounds(200, 270, 75, 35);
		actualSDFld.setEnabled(false);
		analyze.add(actualSDFld);
		
		diffLbl = new JLabel("Difference", JLabel.CENTER);
		diffLbl.setFont(font);
		diffLbl.setVisible(true);
		diffLbl.setBounds(280, 55, 75, 20);
		analyze.add(diffLbl);
		
		diffMeanFld = new JTextField("0.0000");
		diffMeanFld.setFont(font);
		diffMeanFld.setVisible(true);
		diffMeanFld.setBounds(280, 90, 75, 35);
		diffMeanFld.setEnabled(false);
		analyze.add(diffMeanFld);
		
		diffMedianFld = new JTextField("0.0000");
		diffMedianFld.setFont(font);
		diffMedianFld.setVisible(true);
		diffMedianFld.setBounds(280, 135, 75, 35);
		diffMedianFld.setEnabled(false);
		analyze.add(diffMedianFld);
		
		diffModeFld = new JTextField("0.0000");
		diffModeFld.setFont(font);
		diffModeFld.setVisible(true);
		diffModeFld.setBounds(280, 180, 75, 35);
		diffModeFld.setEnabled(false);
		analyze.add(diffModeFld);
		
		diffVarFld = new JTextField("0.0000");
		diffVarFld.setFont(font);
		diffVarFld.setVisible(true);
		diffVarFld.setBounds(280, 225, 75, 35);
		diffVarFld.setEnabled(false);
		analyze.add(diffVarFld);
		
		diffSDFld = new JTextField("0.0000");
		diffSDFld.setFont(font);
		diffSDFld.setVisible(true);
		diffSDFld.setBounds(280, 270, 75, 35);
		diffSDFld.setEnabled(false);
		analyze.add(diffSDFld);
	}
	
	public void initCards() {		
		frontCardPane = new JPanel();
		frontCardPane.setLayout(null);
		frontCardPane.setBounds(15, 10, 180, 290);
		frontCardPane.setVisible(true);
		frontCardPane.setBackground(Color.WHITE);
		frontCardPane.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		cardsPane.add(frontCardPane);
		
		frontImage = new JLabel();
		frontImage.setHorizontalAlignment(JLabel.CENTER);
		frontImage.setBounds(0, 0, 180, 290);
		frontImage.setVisible(true);
		frontCardPane.add(frontImage);
		
		backCardPane = new JPanel();
		backCardPane.setLayout(null);
		backCardPane.setBounds(205, 10, 180, 290);
		backCardPane.setVisible(true);
		backCardPane.setBackground(Color.WHITE);
		backCardPane.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		cardsPane.add(backCardPane);
		
		backImage = new JLabel();
		backImage.setHorizontalAlignment(JLabel.CENTER);
		backImage.setBounds(0, 0, 180, 290);
		backImage.setIcon(new ImageIcon(this.getClass().getResource("/res/cards/back.png")));
		backImage.setVisible(true);
		backCardPane.add(backImage);
	}
	
	public void initIdealGraphs() {
		
	}
	
	public void initActualGraphs() {
		
	}
}
